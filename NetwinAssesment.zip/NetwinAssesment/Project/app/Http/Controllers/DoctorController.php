<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Doctor;
use App\Models\TimeAvailability;

class DoctorController extends Controller
{
    function show()
    {
        $data = Doctor::paginate(10);
        $var = TimeAvailability::all();
        return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
    }

    function showdata($id)
    {
        return Doctor::find($id)->timeavailability;
    }

    public function add()
    {
        $data = Doctor::all();
        return view('addavailability',['doctors'=>$data]);
    }

    public function adddata(Request $request)
    {
        $ta = new TimeAvailability();
        $ta->doctor_id = $request->doc;
        $ta->days = $request->day;
        $ta->start_time = $request->stime;
        $ta->end_time = $request->etime;
        $ta->save();
        session()->flash('status','Time Availability Added Successfully!!!');
        return redirect('/');
        // return $ta;
    }

    function edit()
    {

    }

    function deletedata($id)
    {
        $var = TimeAvailability::where('doctor_id',$id)->get('time_id');
        TimeAvailability::whereIn('time_id',$var)->delete();
        $data = Doctor::paginate(10);
        session()->flash('status','Time Availability Deleted Successfully!!!');
        return redirect()->back();
        // return view('showdoctor',['doctors'=>$data]);
        // return $var;
    }

    function searchdata(Request $request)
    {
        $day = $request->day;
        $doc = $request->doc;
        $time = $request->time;
        if($day!="" && $doc!="" && $time!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('days',$day)->where('doctor_id',$doc)->where('start_time', '<', $time)->where('end_time', '>', $time)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($day!="" && $doc!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('days',$day)->where('doctor_id',$doc)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($doc!="" && $time!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('doctor_id',$doc)->where('start_time', '<', $time)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($day!="" && $time!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('days',$day)->where('start_time', '<', $time)->where('end_time', '>', $time)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($day!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('days',$day)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($doc!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('doctor_id',$doc)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
        else if($time!="")
        {
            $data = Doctor::paginate(10);
            $var = TimeAvailability::where('start_time', '<', $time)->where('end_time', '>', $time)->get();
            return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
        }
            // $data = Doctor::paginate(10);
            // $data = Doctor::paginate(10);
            // $var = TimeAvailability::all();
            // return view('showdoctor',['doctors'=>$data,'timea'=>$var]);
            return redirect('/');
    }
}
