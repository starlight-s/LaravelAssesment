
    <div class="modal fade" id="ModalShow<?php echo e($d['doctor_id']); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Time Availability</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-labble="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Day : Monday
                    Start Time : 23.00
                    End Time : 7.00
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH E:\assesment\NetwinAssesment\Project\resources\views/showavailability.blade.php ENDPATH**/ ?>