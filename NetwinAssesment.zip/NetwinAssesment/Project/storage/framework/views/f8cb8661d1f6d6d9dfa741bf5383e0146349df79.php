
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
</head>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-6 offset-3">
        <div class="card">
                <form action="" method="POST">
                <div class="form-group">
				<label>Doctor</label>
			        <?php if(isset($data['doctors'])): ?>                   
                    <select class="form-control" name="category">
                        <?php $__currentLoopData = $data['doctors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d['doctor_id']); ?>"><?php echo e($d['doctor_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php endif; ?>
			    </div>
                <div class="form-group">
				<label>Time Availability</label>
			       <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <input type="checkbox" aria-label="Checkbox for following text input"> Monday
                            </div>
                        </div>
                        <input type="text" name="stime" id="timepickerexample1" class="form-control">
                        <input type="text" name="etime" id="timepickerexample2" class="form-control">
                    </div>
			    </div>
                </form>
        </div>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function(){
        $('#timepickerexample1').timepicker({
                timeFormat: 'HH:mm:ss',
                interval: 60,
                // minTime: '00',
                // maxTime: '11:00pm',
                defaultTime: '00',
                startTime: '10:00',
                dynamic: false,
                dropdown: true,
                scrollbar: true
        });
        });
    </script>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\assesment\NetwinAssesment\Project\resources\views/addavailability.blade.php ENDPATH**/ ?>