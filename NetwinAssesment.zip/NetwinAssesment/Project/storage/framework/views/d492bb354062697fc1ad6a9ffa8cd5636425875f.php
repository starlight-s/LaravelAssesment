
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
</head>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-6 offset-3">
        <div class="mybutton d-flex justify-content-end">
            <a href="/add" class="btn btn-success">Add Appointment Time</a>
        </div>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
        <table class="table table-striped">
        <tr>
            <th scope="col">Doctor Name</th>
            <th scope="col">Address</th>
            <th scope="col" colspan="2">Action</th>
        </tr>
        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="#" data-toggle="modal" data-target="#ModalShow<?php echo e($d['doctor_id']); ?>"><?php echo e($d['doctor_name']); ?></a></td>
            <td><?php echo e($d['address']); ?></td>
            <td><a href="/edit/<?php echo e($d['doctor_id']); ?>"><i class="fa fa-pencil"></i></a></td>
            <!-- <td><a href="/deletedata/<?php echo e($d['doctor_id']); ?>"><i class="fa fa-remove"></i></a></td> -->
            <td><a href="#" data-toggle="modal" data-target="#ModalDelete<?php echo e($d['doctor_id']); ?>"><i class="fa fa-remove"></i></a></td>
            <?php echo $__env->make('showavailability', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('deleteavailability', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <table>
        
        <?php echo e($doctors->links()); ?>

        </div>
    </div>
    </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\assesment\NetwinAssesment\Project\resources\views/showdoctor.blade.php ENDPATH**/ ?>