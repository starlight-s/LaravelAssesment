<form action="/deletedata/<?php echo e($d['doctor_id']); ?>" method="get" enctype="multipart/form-data">
    <?php echo e(method_field('delete')); ?>

    <?php echo e(csrf_field()); ?>

    <div class="modal fade" id="ModalDelete<?php echo e($d['doctor_id']); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete Time Availability</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-labble="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">Are You Sure You Want To Delete?</div>
                <div class="modal-footer">
                    <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-outline-danger">Delete</button>
                </div>
            </div>
        </div>
    </div>
</form><?php /**PATH E:\assesment\NetwinAssesment\Project\resources\views/deleteavailability.blade.php ENDPATH**/ ?>