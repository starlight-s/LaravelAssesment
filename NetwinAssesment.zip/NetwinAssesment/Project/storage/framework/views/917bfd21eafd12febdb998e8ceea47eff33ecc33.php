
    <div class="modal fade" id="ModalShow<?php echo e($d['doctor_id']); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Time Availability</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-labble="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <?php $__currentLoopData = $timea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($d['doctor_id']==$t['doctor_id']): ?>
                <b>Day : </b><?php if($t['days']==1): ?> Monday 
                    <?php elseif($t['days']==2): ?> Tuesday 
                    <?php elseif($t['days']==3): ?> Wednesday 
                    <?php elseif($t['days']==4): ?> Thursday 
                    <?php elseif($t['days']==5): ?> Friday 
                    <?php elseif($t['days']==6): ?> Saturday 
                    <?php elseif($t['days']==7): ?> Sunday 
                    <?php endif; ?>
                     
                    <b>Status : </b><?php if($t['open_status']==1): ?> Available
                    <?php else: ?> Not Available
                    <?php endif; ?>

                    <b>Start Time : </b><?php echo e($t['start_time']); ?>


                    <b>End Time : </b><?php echo e($t['end_time']); ?>

                    <br>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH E:\SNEHA\Project\NetwinAssesment\Project\resources\views/showavailability.blade.php ENDPATH**/ ?>