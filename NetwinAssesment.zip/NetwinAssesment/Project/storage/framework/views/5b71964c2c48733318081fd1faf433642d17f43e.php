
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-6 offset-3">
        <div class="card">
                <form action="/adddata" method="POST" class="form-group row">
                <?php echo csrf_field(); ?>
                <div class="form-group">
				<label>Doctor</label>                 
                    <select class="form-control" name="doc">
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d['doctor_id']); ?>"><?php echo e($d['doctor_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
			    </div>
                <div class="form-group">
				<label>Time Availability</label>
			       <div class="input-group">
                        <div class="input-group-prepend">
                            <div >
                                <input type="checkbox" value="1" name="day"> Monday
                            </div>
                        </div>
                        <input class="timepicker form-control mb-2" type="text" id="time" name="stime">
                        <input class="timepicker form-control mb-2" type="text" id="time" name="etime">
                    </div>
			    </div>
                <input type="reset" value="Clear" class="btn btn-secondary col-6">
                <input type="submit" value="Save" class="btn btn-primary col-6">
                </form>
        </div>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>  
<script type="text/javascript">

$('.timepicker').datetimepicker({

    format: 'HH:mm:ss'

}); 

</script> 
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SNEHA\Project\NetwinAssesment\Project\resources\views/addavailability.blade.php ENDPATH**/ ?>