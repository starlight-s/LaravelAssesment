@extends('welcome')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-6 offset-3">
        
        <div class="mybutton d-flex justify-content-end">
            <a href="/add" class="btn btn-success">Add Appointment Time</a>
        </div>
        <div class="d-flex">  
            <form method="POST" action="/searchdata" class="form-inline">
                @csrf
            <select class="form-control mb-2" name="day" >
                    <option value="">Choose Day</option>
                    <option value="1">Monday</option>
                    <option value="2">Tuesday</option>
                    <option value="3">Wednesday</option>
                    <option value="4">Thursday</option>
                    <option value="5">Friday</option>
                    <option value="6">Saturday</option>
                    <option value="7">Sunday</option>
            </select> 
            <select class="form-control mb-2" name="doc">
            <option value="">Choose Doctor</option>
                @foreach($doctors as $d)
                    <option value="{{$d['doctor_id']}}">{{$d['doctor_name']}}</option>
                @endforeach
            </select>   
            <input class="timepicker form-control mb-2" type="text" id="time" name="time">
            <input type="submit" value="Search" class="btn btn-primary">
            </form>
        </div>
        @if (session('status'))
            <div class="alert alert-secodary" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <div class="card">
        <table class="table table-striped">
        <tr>
            <th scope="col">Doctor Name</th>
            <th scope="col">Address</th>
            <th scope="col" colspan="2">Action</th>
        </tr>
        @foreach($doctors as $d)
        <tr>
            <td><a href="#" data-toggle="modal" data-target="#ModalShow{{$d['doctor_id']}}">{{$d['doctor_name']}}</a></td>
            <td>{{$d['address']}}</td>
            <td><a href="/edit/{{$d['doctor_id']}}"><i class="fa fa-pencil"></i></a></td>
            <!-- <td><a href="/deletedata/{{$d['doctor_id']}}"><i class="fa fa-remove"></i></a></td> -->
            <td><a href="/showdata/{{$d['doctor_id']}}" data-toggle="modal" data-target="#ModalDelete{{$d['doctor_id']}}"><i class="fa fa-remove"></i></a></td>
            @include('showavailability')
            @include('deleteavailability')
        </tr>
        @endforeach
        <table>
        
        {{$doctors->links()}}
        </div>
    </div>
    </div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>  
<script type="text/javascript">

$('.timepicker').datetimepicker({

    format: 'HH:mm:ss'

}); 

</script>  
</body>
</html>
@endsection