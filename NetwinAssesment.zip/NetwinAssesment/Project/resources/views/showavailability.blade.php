
    <div class="modal fade" id="ModalShow{{$d['doctor_id']}}" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Time Availability</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-labble="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                @foreach($timea as $t)
                @if($d['doctor_id']==$t['doctor_id'])
                <b>Day : </b>@if($t['days']==1) Monday 
                    @elseif($t['days']==2) Tuesday 
                    @elseif($t['days']==3) Wednesday 
                    @elseif($t['days']==4) Thursday 
                    @elseif($t['days']==5) Friday 
                    @elseif($t['days']==6) Saturday 
                    @elseif($t['days']==7) Sunday 
                    @endif
                     
                    <b>Status : </b>@if($t['open_status']==1) Available
                    @else($t['open_status']==0) Not Available
                    @endif

                    <b>Start Time : </b>{{$t['start_time']}}

                    <b>End Time : </b>{{$t['end_time']}}
                    <br>
                @endif
                @endforeach
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn gray btn-outline-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
