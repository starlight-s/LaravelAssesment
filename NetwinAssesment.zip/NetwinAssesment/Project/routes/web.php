<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DoctorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get("/",[DoctorController::class,'show']);
Route::get('/showdata/{id}',[DoctorController::class,'showdata']);
Route::post('/searchdata',[DoctorController::class,'searchdata']);

Route::get('/add',[DoctorController::class,'add']);
Route::post('/adddata',[DoctorController::class,'adddata']);

Route::get('/deletedata/{id}',[DoctorController::class,'deletedata']);

